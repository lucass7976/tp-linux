
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren 2 argumentos: <origen> <destino>"
    echo "Usá -h para ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar si origen y destino existen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: Directorio de origen '$ORIGEN' no existe"
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: Directorio de destino '$DESTINO' no existe"
    exit 3
fi

# Crear nombre del archivo con fecha
FECHA=$(date +%Y%m%d)
NOMBRE_BACKUP="$(basename $ORIGEN)_bkp_${FECHA}.tar.gz"

# Ejecutar backup
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"

echo "Backup de $ORIGEN completado en $DESTINO/$NOMBRE_BACKUP"

